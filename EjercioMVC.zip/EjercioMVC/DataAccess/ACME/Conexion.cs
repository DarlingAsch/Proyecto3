﻿using Microsoft.Data.SqlClient;

namespace DataAccess.ACME
{
    public class Conexion
    {
        private readonly string? _CadenaConexion;

        public Conexion()
        {
           string? CadenaConexion;

            CadenaConexion = Environment.GetEnvironmentVariable("SQLServerXE");

            _CadenaConexion = CadenaConexion;

        }

        public SqlConnection Conectar()
        {
            SqlConnection sqlConn;

            sqlConn = new SqlConnection(_CadenaConexion);

            return sqlConn;
        }



    }
}
